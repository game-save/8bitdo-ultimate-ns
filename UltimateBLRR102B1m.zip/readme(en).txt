
The Bluetooth Receiver for Ultimate Controller

V1.02 Beta 1 Update log:
There are several button combinations to activate different working modes on 2.4g mode to meet the need of different devices. 
Press & hold the following button combinations for 5 seconds after the connection between the controller and receiver, 
the LED indicator blinks rapidly a few times to indicate the successful switching. 

Switch mode: SELECT+Y         (Apply for Steam Deck & Switch)
Xinput mode: SELECT+X         (Apply for Windows 10 1903 or above)
Dinput mode: SELECT+B         (Apply for Mister, Android and Linux)
Default mode: SELECT+START     (Automatically identify Windows and Switch) 


Upgrade instructions:
1.Run the [8BitDo_UM_BT_Receiver.exe] on PC.
2. Plug the Ultimate Bluetooth Controller's 2.4g receiver into PC.
3. Click "USB update" button and choose the [UM_BT_Receiver_V1.02_Beta1.dat] file to upgrade.